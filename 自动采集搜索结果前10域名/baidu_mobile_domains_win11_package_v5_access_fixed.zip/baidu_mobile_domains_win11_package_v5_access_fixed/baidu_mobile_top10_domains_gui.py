import csv
import json
import os
import queue
import random
import re
import sys
import threading
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from html import unescape
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote, unquote, urljoin, urlparse, urlsplit

import requests
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

APP_TITLE = "百度移动搜索前10域名提取工具"
DEFAULT_OUTPUT = "百度移动搜索前10域名.csv"
DEFAULT_LOG = "百度移动搜索前10域名.log"
DEFAULT_KEYWORDS = "keywords.txt"
MAX_RESULTS = 10
MAX_PAGES = 10
PAGE_LOAD_TIMEOUT = 18
WAIT_TIMEOUT = 7
ACCESS_TIMEOUT = 6
ACCESS_WORKERS = 5

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
)

EXCLUDED_HOSTS = {
    "m.baidu.com",
    "www.baidu.com",
    "passport.baidu.com",
    "voice.baidu.com",
    "smartapp.baidu.com",
    "fakeurl.ubs.baidu.com",
    "nourl.ubs.baidu.com",
    "hao123.com",
    "www.hao123.com",
    "m.hao123.com",
    "activity.baidu.com",
    "ufosdk.baidu.com",
    "gips1.baidu.com",
    "yiqifu.baidu.com",
    "isite.baidu.com",
    "map.baidu.com",
    "b2b.baidu.com",
}

EXCLUDED_HOST_SUFFIXES = (
    ".recommend_list.baidu.com",
    ".ubs.baidu.com",
)

NO_RESULT_PATTERNS = [
    "抱歉，没有找到与",
    "未找到相关结果",
    "没有找到相关结果",
    "没有找到与",
    "暂无搜索结果",
    "未找到您要找的内容",
    "很抱歉，没有找到",
    "未查询到相关结果",
]

RESULT_SELECTORS = [
    "div.c-result.result[order]",
    "#results div.c-result.result[order]",
    "div.result[order]",
    "div[class*='c-result'][order]",
]

URL_ATTR_NAMES = {
    "href",
    "data-url",
    "data-link",
    "rl-link-href",
    "rl-link-data-url",
}

JSON_ATTR_NAMES = {
    "data-log",
    "data-click-info",
    "data-show-ext",
    "data-ivk",
    "data-ext",
    "rl-link-data-log",
    "rl-link-data-click",
}


def get_app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = get_app_dir()
LOG_PATH = APP_DIR / DEFAULT_LOG
DEBUG_DIR = APP_DIR / "debug_html"


class Logger:
    def __init__(self, callback=None):
        self.callback = callback

    def write(self, message: str) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {message}"
        try:
            with LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        if self.callback:
            self.callback(line)


@dataclass
class SearchResult:
    keyword: str
    domains: List[str]
    status: str
    note: str = ""
    inaccessible_domains: List[str] = field(default_factory=list)
    inaccessible_details: List[str] = field(default_factory=list)


@dataclass
class ParsedCard:
    order: int
    text: str
    url: str


class DomainExtractor:
    def __init__(self, logger: Logger, headless: bool = True, delay: float = 1.2, save_html: bool = False):
        self.logger = logger
        self.headless = headless
        self.delay = max(0.0, delay)
        self.save_html = save_html
        self.driver: Optional[webdriver.Chrome] = None
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "zh-CN,zh;q=0.9",
        })

    def start(self) -> None:
        options = Options()
        mobile_emulation = {
            "deviceMetrics": {"width": 412, "height": 915, "pixelRatio": 2.625},
            "userAgent": USER_AGENT,
        }
        options.add_experimental_option("mobileEmulation", mobile_emulation)
        options.add_argument("--lang=zh-CN")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=430,960")
        if self.headless:
            options.add_argument("--headless=new")
        self.driver = webdriver.Chrome(service=Service(), options=options)
        self.driver.set_page_load_timeout(PAGE_LOAD_TIMEOUT)
        self.logger.write("Chrome 浏览器驱动已启动。")

    def close(self) -> None:
        try:
            if self.driver:
                self.driver.quit()
        except Exception:
            pass
        self.driver = None

    def search_keyword(self, keyword: str) -> SearchResult:
        assert self.driver is not None, "Driver not started"
        query = normalize_keyword(keyword)
        if not query:
            return SearchResult(keyword="", domains=[], status="跳过", note="空关键词")

        self.logger.write(f"开始搜索关键词：{query}")
        all_domains: List[str] = []
        blocked = False
        seen_pages = set()
        no_new_count = 0

        for page_index in range(1, MAX_PAGES + 1):
            pn = (page_index - 1) * 10
            page_url = f"https://m.baidu.com/s?word={quote(query)}&pn={pn}"
            if page_url in seen_pages:
                break
            seen_pages.add(page_url)

            page_timed_out = False
            try:
                self.driver.get(page_url)
            except TimeoutException:
                page_timed_out = True
                self.logger.write(f"页面加载超时：{query}（第 {page_index} 页），尝试直接解析当前内容。")
                try:
                    self.driver.execute_script("window.stop();")
                except Exception:
                    pass
            except WebDriverException as exc:
                return SearchResult(keyword=query, domains=[], status="错误", note=f"浏览器错误：{exc}")

            if not page_timed_out:
                self._wait_for_page_ready()
            time.sleep(self.delay + random.uniform(0.15, 0.45))

            html = self.driver.page_source
            current_url = self.driver.current_url
            page_title = self.driver.title or ""

            if self.save_html:
                self._save_debug_html(query, html, suffix=f"第{page_index}页")

            if self._looks_like_blocked(html, current_url, page_title):
                blocked = True
                self._save_debug_html(query, html, suffix=f"第{page_index}页_拦截")
                break

            if self._looks_like_no_results(html, current_url, page_title):
                if page_index == 1 and not all_domains:
                    self.logger.write(f"{query}：首屏判定为无搜索结果，快速跳过。")
                    return SearchResult(keyword=query, domains=[], status="无结果", note="该关键词未找到可用搜索结果")
                break

            page_domains = self._extract_domains_from_result_cards(html)
            if not page_domains:
                anchors = self._extract_candidate_anchors_from_html(html, current_url)
                if anchors:
                    page_domains = self._resolve_domains(anchors)

            if page_domains:
                self.logger.write(f"第 {page_index} 页提取到 {len(page_domains)} 个候选域名。")
                before_count = len(all_domains)
                all_domains = merge_unique_strings(all_domains, page_domains)
                added = len(all_domains) - before_count
                self.logger.write(f"当前累计唯一域名 {len(all_domains)} 个，本页新增 {added} 个。")
                no_new_count = 0 if added > 0 else no_new_count + 1
            else:
                self.logger.write(f"第 {page_index} 页未提取到有效域名。")
                no_new_count += 1
                if page_index == 1:
                    self._save_debug_html(query, html, suffix="首屏未提取到结果")

            if len(all_domains) >= MAX_RESULTS:
                break
            if no_new_count >= 2 and page_index >= 2:
                self.logger.write("连续两页没有新增域名，停止继续翻页。")
                break

        if blocked and not all_domains:
            return SearchResult(keyword=query, domains=[], status="被拦截", note="百度可能触发了验证或访问限制")

        if not all_domains:
            self._save_debug_html(query, self.driver.page_source, suffix="未提取到结果")
            return SearchResult(keyword=query, domains=[], status="失败", note="未提取到有效域名")

        domains = all_domains[:MAX_RESULTS]
        inaccessible_domains, inaccessible_details = self._check_domains_accessibility(domains)

        if len(domains) < MAX_RESULTS:
            note = f"仅提取到 {len(domains)} 个唯一域名（已自动翻页补足）"
            status = "部分成功"
        else:
            note = f"已提取前 {MAX_RESULTS} 个域名"
            status = "成功"

        if inaccessible_domains:
            note += f"；不可访问 {len(inaccessible_domains)} 个"

        return SearchResult(
            keyword=query,
            domains=domains,
            status=status,
            note=note,
            inaccessible_domains=inaccessible_domains,
            inaccessible_details=inaccessible_details,
        )

    def _wait_for_page_ready(self) -> None:
        assert self.driver is not None
        wait = WebDriverWait(self.driver, WAIT_TIMEOUT)
        try:
            wait.until(lambda d: d.execute_script("return document.readyState") == "complete")
        except TimeoutException:
            pass
        selectors = [
            "#results div.c-result.result[order]",
            "div.c-result.result[order]",
            "div.result[order]",
            "body",
        ]
        for selector in selectors:
            try:
                wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                return
            except TimeoutException:
                continue

    def _looks_like_blocked(self, html: str, current_url: str, page_title: str) -> bool:
        signals = [current_url, page_title, html[:8000]]
        joined = "\n".join(s for s in signals if s).lower()
        patterns = [
            "验证码",
            "安全验证",
            "请完成以下验证",
            "请输入验证码",
            "访问受限",
            "network anomaly",
            "captcha",
            "antirobot",
        ]
        return any(p.lower() in joined for p in patterns)

    def _looks_like_no_results(self, html: str, current_url: str, page_title: str) -> bool:
        soup = BeautifulSoup(html, "html.parser")
        result_cards = soup.select("#results div.c-result.result[order], div.c-result.result[order]")
        if result_cards:
            return False
        combined = normalize_text(" ".join([current_url or "", page_title or "", soup.get_text(" ", strip=True)]))
        if any(pattern in combined for pattern in NO_RESULT_PATTERNS):
            return True
        for selector in [".no-result", ".c-noresult", ".c-result-no-content", "#page-bd .no-result"]:
            if soup.select_one(selector):
                return True
        return False

    def _extract_domains_from_result_cards(self, html: str) -> List[str]:
        cards = self._parse_result_cards(html)
        if cards:
            self.logger.write(f"从渲染后的页面中解析到 {len(cards)} 个结果卡片。")
        domains: List[str] = []
        for card in cards:
            host = extract_host(card.url)
            if not host:
                continue
            if self._should_skip_host(host):
                continue
            if host not in domains:
                domains.append(host)
        return domains

    def _parse_result_cards(self, html: str) -> List[ParsedCard]:
        soup = BeautifulSoup(html, "html.parser")
        raw_cards = soup.select("#results div.c-result.result[order]") or soup.select("div.c-result.result[order]")
        parsed: List[ParsedCard] = []
        for res in raw_cards:
            card = self._parse_single_result_card(res)
            if card:
                parsed.append(card)
        parsed.sort(key=lambda x: (x.order, x.text))
        return parsed

    def _parse_single_result_card(self, res) -> Optional[ParsedCard]:
        order = safe_int(res.get("order"), default=999999)
        text = normalize_text(res.get_text(" ", strip=True))
        candidate_urls = self._extract_candidate_urls_from_card(res)
        best_url = self._choose_best_url(candidate_urls)
        if not best_url:
            return None
        return ParsedCard(order=order, text=text, url=best_url)

    def _extract_candidate_urls_from_card(self, res) -> List[str]:
        urls: List[str] = []
        seen_attr_values = set()
        for tag in [res] + list(res.find_all(True)):
            attrs = getattr(tag, "attrs", {}) or {}
            for attr_name, attr_value in attrs.items():
                name = str(attr_name).lower().strip()
                values = attr_value if isinstance(attr_value, list) else [attr_value]
                for one in values:
                    if not isinstance(one, str):
                        continue
                    raw = one.strip()
                    if not raw or raw in seen_attr_values:
                        continue
                    seen_attr_values.add(raw)
                    if name in URL_ATTR_NAMES:
                        urls.extend(self._extract_urls_from_text(raw))
                    elif name in JSON_ATTR_NAMES:
                        urls.extend(self._extract_urls_from_maybe_json(raw))
                    else:
                        if name.startswith("data-") or name.startswith("rl-link-"):
                            urls.extend(self._extract_urls_from_maybe_json(raw))
        return dedupe_strings([u for u in urls if self._is_meaningful_candidate_url(u)])

    def _extract_urls_from_maybe_json(self, raw: str) -> List[str]:
        text = raw.strip()
        urls: List[str] = []
        for _ in range(3):
            decoded = unquote(text)
            if decoded == text:
                break
            text = decoded

        for attempt in (raw, text):
            if not isinstance(attempt, str):
                continue
            attempt_str = attempt.strip()
            if not attempt_str:
                continue
            if attempt_str.startswith("{") or attempt_str.startswith("["):
                try:
                    obj = json.loads(attempt_str)
                    urls.extend(self._collect_urls_from_obj(obj))
                except Exception:
                    pass
            urls.extend(self._extract_urls_from_text(attempt_str))
        return urls

    def _collect_urls_from_obj(self, obj) -> List[str]:
        out: List[str] = []
        if isinstance(obj, dict):
            for key, value in obj.items():
                key_l = str(key).lower()
                if isinstance(value, str):
                    if key_l in {"mu", "url", "dataurl", "data_url", "invoke_url", "default_url", "jumpurl", "jump_url"}:
                        out.extend(self._extract_urls_from_text(value))
                    else:
                        out.extend(self._extract_urls_from_text(value))
                else:
                    out.extend(self._collect_urls_from_obj(value))
        elif isinstance(obj, list):
            for item in obj:
                out.extend(self._collect_urls_from_obj(item))
        elif isinstance(obj, str):
            out.extend(self._extract_urls_from_text(obj))
        return out

    def _extract_urls_from_text(self, text: str) -> List[str]:
        cleaned = unescape(text or "")
        urls = re.findall(r"https?://[^\s\"'<>\\]+", cleaned, flags=re.I)
        out: List[str] = []
        for url in urls:
            url = url.rstrip(",);]\u3002\uFF0C")
            if url:
                out.append(url)
        return out

    def _is_meaningful_candidate_url(self, url: str) -> bool:
        host = extract_host(url)
        if not host:
            return False
        low = url.lower()
        if any(low.endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".heic", ".mp3", ".mp4")):
            return False
        if host.startswith("gimg") and host.endswith("baidu.com"):
            return False
        return True

    def _choose_best_url(self, urls: Sequence[str]) -> str:
        direct_urls: List[str] = []
        redirect_urls: List[str] = []
        for url in urls:
            host = extract_host(url)
            if not host:
                continue
            if self._should_skip_host(host):
                continue
            if host.endswith("baidu.com") or host.endswith("baidu.cn"):
                redirect_urls.append(url)
            else:
                direct_urls.append(url)
        if direct_urls:
            return direct_urls[0]
        for url in redirect_urls:
            resolved = self._resolve_url(url)
            host = extract_host(resolved)
            if host and not self._should_skip_host(host):
                return resolved
        return ""

    def _extract_candidate_anchors_from_html(self, html: str, current_url: str) -> List[Tuple[str, str]]:
        soup = BeautifulSoup(html, "html.parser")
        items: List[Tuple[str, str]] = []
        selectors = [
            "#results h3 a[href]",
            "div.c-result.result[order] a[href]",
            "h3 a[href]",
        ]
        for selector in selectors:
            for a in soup.select(selector):
                href = urljoin(current_url, (a.get("href") or "").strip())
                text = a.get_text(" ", strip=True)
                if self._is_candidate_anchor(href, text):
                    items.append((href, text))
        return self._dedupe_preserve_order(items)

    def _is_candidate_anchor(self, href: str, text: str) -> bool:
        if not href:
            return False
        href_l = href.lower()
        if href_l.startswith(("javascript:", "mailto:", "tel:")):
            return False
        if href_l.startswith("#"):
            return False
        if any(k in href_l for k in ["passport.baidu.com", "voice.baidu.com", "image.baidu.com", "map.baidu.com"]):
            return False
        bad_text = ["百度一下", "相关搜索", "下一页", "上一页", "更多结果", "使用百度前必读"]
        if text and any(t in text for t in bad_text):
            return False
        return href_l.startswith("http")

    def _resolve_domains(self, anchors: Sequence[Tuple[str, str]]) -> List[str]:
        domains: List[str] = []
        for href, _text in anchors:
            final_url = self._resolve_url(href)
            host = extract_host(final_url)
            if not host:
                continue
            if self._should_skip_host(host):
                continue
            if host not in domains:
                domains.append(host)
        return domains

    def _resolve_url(self, href: str) -> str:
        host = extract_host(href)
        if host and not (host.endswith("baidu.com") or host.endswith("baidu.cn")):
            return href
        try:
            response = self.session.get(href, timeout=10, allow_redirects=True, verify=False)
            return response.url or href
        except Exception:
            return href

    def _should_skip_host(self, host: str) -> bool:
        host = host.lower().strip().rstrip(".")
        if not host:
            return True
        if host in EXCLUDED_HOSTS:
            return True
        if any(host.endswith(suffix) for suffix in EXCLUDED_HOST_SUFFIXES):
            return True
        if host == "baidu.com" or host == "baidu.cn":
            return True
        return False

    def _check_domains_accessibility(self, domains: Sequence[str]) -> Tuple[List[str], List[str]]:
        if not domains:
            return [], []
        results = []
        with ThreadPoolExecutor(max_workers=min(ACCESS_WORKERS, len(domains))) as executor:
            future_map = {executor.submit(self._check_one_domain, domain): domain for domain in domains}
            for future in as_completed(future_map):
                domain = future_map[future]
                try:
                    ok, detail = future.result()
                except Exception as exc:
                    ok, detail = False, f"检测异常：{exc}"
                results.append((domain, ok, detail))
        ordered = {domain: (ok, detail) for domain, ok, detail in results}
        inaccessible_domains: List[str] = []
        inaccessible_details: List[str] = []
        for domain in domains:
            ok, detail = ordered.get(domain, (False, "未得到检测结果"))
            if not ok:
                inaccessible_domains.append(domain)
                inaccessible_details.append(f"{domain}（{detail}）")
        return inaccessible_domains, inaccessible_details

    def _check_one_domain(self, domain: str) -> Tuple[bool, str]:
        headers = {
            "User-Agent": USER_AGENT,
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
        attempts = [f"https://{domain}", f"http://{domain}"]
        last_detail = "连接失败"
        for url in attempts:
            try:
                resp = requests.get(
                    url,
                    headers=headers,
                    timeout=ACCESS_TIMEOUT,
                    allow_redirects=True,
                    verify=False,
                    stream=True,
                )
                code = resp.status_code
                final_url = resp.url
                try:
                    resp.close()
                except Exception:
                    pass
                if 200 <= code < 400:
                    return True, f"HTTP {code}"
                last_detail = f"HTTP {code}"
                if 400 <= code < 500:
                    return False, last_detail
            except requests.exceptions.SSLError:
                last_detail = "SSL 错误"
            except requests.exceptions.ConnectTimeout:
                last_detail = "连接超时"
            except requests.exceptions.ReadTimeout:
                last_detail = "读取超时"
            except requests.exceptions.ConnectionError:
                last_detail = "连接失败"
            except Exception as exc:
                last_detail = str(exc)
        return False, last_detail

    def _save_debug_html(self, keyword: str, html: str, suffix: str = "") -> None:
        DEBUG_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^0-9A-Za-z一-鿿._-]+", "_", keyword).strip("._") or "keyword"
        safe_suffix = re.sub(r"[^0-9A-Za-z一-鿿._-]+", "_", suffix).strip("._")
        filename = f"{safe_name}{'_' + safe_suffix if safe_suffix else ''}.html"
        path = DEBUG_DIR / filename
        try:
            path.write_text(html, encoding="utf-8")
            self.logger.write(f"调试 HTML 已保存：{path}")
        except Exception as exc:
            self.logger.write(f"保存调试 HTML 失败：{exc}")

    @staticmethod
    def _dedupe_preserve_order(items: Iterable[Tuple[str, str]]) -> List[Tuple[str, str]]:
        seen = set()
        out = []
        for href, text in items:
            key = (href.strip(), text.strip())
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1080x760")
        self.root.minsize(920, 680)

        self.msg_queue: queue.Queue[Tuple[str, object]] = queue.Queue()
        self.worker: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()
        self.current_rows: List[SearchResult] = []

        self.keywords_path = tk.StringVar(value=str(APP_DIR / DEFAULT_KEYWORDS))
        self.output_path = tk.StringVar(value=str(APP_DIR / DEFAULT_OUTPUT))
        self.headless_var = tk.BooleanVar(value=True)
        self.save_html_var = tk.BooleanVar(value=False)
        self.delay_var = tk.StringVar(value="1.0")
        self.status_var = tk.StringVar(value="就绪")
        self.progress_var = tk.DoubleVar(value=0.0)

        self._build_ui()
        self.logger = Logger(self._enqueue_log)
        self.root.after(100, self._process_queue)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        form = ttk.LabelFrame(outer, text="任务设置", padding=12)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="关键词 TXT").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.keywords_path).grid(row=0, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="浏览", command=self._browse_keywords).grid(row=0, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="导出 CSV").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.output_path).grid(row=1, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="浏览", command=self._browse_output).grid(row=1, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="间隔秒数").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.delay_var, width=12).grid(row=2, column=1, sticky="w", pady=6)

        opts = ttk.Frame(form)
        opts.grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Checkbutton(opts, text="无头模式运行 Chrome", variable=self.headless_var).pack(side="left", padx=(0, 18))
        ttk.Checkbutton(opts, text="为每个关键词保存调试 HTML", variable=self.save_html_var).pack(side="left")

        tip = ttk.Label(
            outer,
            text=(
                "TXT 文件中一行就是一组关键词，允许包含标点符号，程序不会按标点拆分。"
                "程序会尽量按百度移动搜索结果原始顺序提取前 10 个唯一域名，"
                "并检测这些域名在当前运行环境下能否正常访问。运行过程中可随时导出当前结果，"
                "同时程序会在每处理完一个关键词后自动保存 CSV。"
            ),
            wraplength=1020,
            justify="left",
        )
        tip.pack(fill="x", pady=(10, 8))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 8))
        self.start_btn = ttk.Button(btns, text="开始提取", command=self.start_task)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="当前关键词完成后停止", command=self.stop_task, state="disabled")
        self.stop_btn.pack(side="left", padx=(8, 0))
        self.export_btn = ttk.Button(btns, text="导出当前结果", command=self.export_current_results)
        self.export_btn.pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="打开程序目录", command=self._open_app_folder).pack(side="right")

        progress_frame = ttk.Frame(outer)
        progress_frame.pack(fill="x", pady=(0, 8))
        self.progress = ttk.Progressbar(progress_frame, maximum=100, variable=self.progress_var)
        self.progress.pack(fill="x")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w", pady=(4, 0))

        table_box = ttk.LabelFrame(outer, text="结果预览", padding=8)
        table_box.pack(fill="both", expand=True)
        columns = ["keyword", "status", "note"] + [f"d{i}" for i in range(1, 11)] + ["bad"]
        self.tree = ttk.Treeview(table_box, columns=columns, show="headings", height=10)
        self.tree.heading("keyword", text="关键词")
        self.tree.column("keyword", width=180, anchor="w")
        self.tree.heading("status", text="状态")
        self.tree.column("status", width=90, anchor="center")
        self.tree.heading("note", text="备注")
        self.tree.column("note", width=220, anchor="w")
        for i in range(1, 11):
            col = f"d{i}"
            self.tree.heading(col, text=f"第{i}个域名")
            self.tree.column(col, width=145, anchor="w")
        self.tree.heading("bad", text="不可访问域名")
        self.tree.column("bad", width=260, anchor="w")

        yscroll = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_box.columnconfigure(0, weight=1)
        table_box.rowconfigure(0, weight=1)

        log_box = ttk.LabelFrame(outer, text="运行日志", padding=8)
        log_box.pack(fill="both", expand=True, pady=(8, 0))
        self.log_text = tk.Text(log_box, height=12, wrap="word")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

    def _browse_keywords(self) -> None:
        path = filedialog.askopenfilename(
            title="选择关键词 TXT 文件",
            filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")],
        )
        if path:
            self.keywords_path.set(path)

    def _browse_output(self) -> None:
        path = filedialog.asksaveasfilename(
            title="选择 CSV 保存位置",
            defaultextension=".csv",
            initialfile=DEFAULT_OUTPUT,
            filetypes=[("CSV 文件", "*.csv")],
        )
        if path:
            self.output_path.set(path)

    def _open_app_folder(self) -> None:
        path = str(APP_DIR)
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo(APP_TITLE, f"程序目录：\n{path}")

    def _enqueue_log(self, line: str) -> None:
        self.msg_queue.put(("log", line))

    def start_task(self) -> None:
        if self.worker and self.worker.is_alive():
            return

        keywords_file = Path(self.keywords_path.get().strip())
        try:
            delay = float(self.delay_var.get().strip())
        except ValueError:
            messagebox.showerror(APP_TITLE, "间隔秒数必须是数字。")
            return

        if not keywords_file.exists():
            messagebox.showerror(APP_TITLE, f"未找到关键词文件：\n{keywords_file}")
            return

        self.tree.delete(*self.tree.get_children())
        self.current_rows = []
        self.stop_flag.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress_var.set(0)
        self.status_var.set("正在启动...")

        self.worker = threading.Thread(
            target=self._run_task,
            args=(keywords_file, Path(self.output_path.get().strip()), delay, self.headless_var.get(), self.save_html_var.get()),
            daemon=True,
        )
        self.worker.start()

    def stop_task(self) -> None:
        self.stop_flag.set()
        self.status_var.set("将在当前关键词完成后停止...")

    def export_current_results(self) -> None:
        if not self.current_rows:
            messagebox.showinfo(APP_TITLE, "当前还没有可导出的结果。")
            return
        output = Path(self.output_path.get().strip())
        if not output.name:
            messagebox.showerror(APP_TITLE, "请先设置 CSV 导出路径。")
            return
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
            write_csv(output, self.current_rows)
            write_inaccessible_csv(output, self.current_rows)
            self._append_log(f"已手动导出当前结果：{output}")
            messagebox.showinfo(APP_TITLE, f"当前结果已导出到：\n{output}\n\n不可访问域名明细：\n{derive_inaccessible_output_path(output)}")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"导出失败：\n{exc}")

    def _auto_save_current_results(self) -> None:
        if not self.current_rows:
            return
        output = Path(self.output_path.get().strip())
        if not output.name:
            return
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
            write_csv(output, self.current_rows)
            write_inaccessible_csv(output, self.current_rows)
        except Exception as exc:
            self._append_log(f"自动保存失败：{exc}")

    def _run_task(self, keywords_file: Path, output_file: Path, delay: float, headless: bool, save_html: bool) -> None:
        try:
            keywords = read_keywords(keywords_file)
            if not keywords:
                self.msg_queue.put(("error", "TXT 文件中没有读到有效关键词。"))
                return

            output_file.parent.mkdir(parents=True, exist_ok=True)
            extractor = DomainExtractor(logger=self.logger, headless=headless, delay=delay, save_html=save_html)
            extractor.start()

            interrupted = False
            try:
                total = len(keywords)
                for idx, keyword in enumerate(keywords, start=1):
                    if self.stop_flag.is_set():
                        interrupted = True
                        self.logger.write("用户请求停止，当前关键词完成后结束。")
                        break
                    result = extractor.search_keyword(keyword)
                    self.msg_queue.put(("row", result))
                    pct = idx / total * 100
                    self.msg_queue.put(("progress", (pct, f"已处理 {idx}/{total}：{keyword}")))
                if interrupted:
                    self.msg_queue.put(("done", f"任务已停止，当前已导出 {len(self.current_rows)} 条结果到：\n{output_file}"))
                else:
                    self.msg_queue.put(("done", f"处理完成。CSV 已保存到：\n{output_file}\n\n不可访问域名明细：\n{derive_inaccessible_output_path(output_file)}"))
            finally:
                extractor.close()
        except Exception as exc:
            self.msg_queue.put(("error", f"未处理异常：\n{exc}"))

    def _process_queue(self) -> None:
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self._append_log(str(payload))
                elif kind == "row":
                    self._add_row(payload)
                elif kind == "progress":
                    pct, text = payload
                    self.progress_var.set(pct)
                    self.status_var.set(text)
                elif kind == "done":
                    self._finish(True, str(payload))
                elif kind == "error":
                    self._finish(False, str(payload))
        except queue.Empty:
            pass
        self.root.after(100, self._process_queue)

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _add_row(self, result: SearchResult) -> None:
        self.current_rows.append(result)
        vals = [result.keyword, result.status, result.note] + result.domains[:10]
        vals += [""] * (13 - len(vals))
        vals.append("；".join(result.inaccessible_domains))
        self.tree.insert("", "end", values=vals)
        self._auto_save_current_results()
        bad_info = f"；不可访问：{', '.join(result.inaccessible_domains)}" if result.inaccessible_domains else ""
        if result.note:
            self._append_log(f"[{result.keyword}] {result.status}：{result.note}{bad_info}")
        else:
            self._append_log(f"[{result.keyword}] {result.status}：{', '.join(result.domains[:10])}{bad_info}")

    def _finish(self, ok: bool, message: str) -> None:
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.progress_var.set(100 if ok else self.progress_var.get())
        self.status_var.set("已完成" if ok else "出错")
        if ok:
            messagebox.showinfo(APP_TITLE, message)
        else:
            messagebox.showerror(APP_TITLE, message)


def read_text_best_effort(path: Path) -> str:
    raw = path.read_bytes()
    encodings = ["utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16", "utf-16le", "utf-16be"]
    for enc in encodings:
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="ignore")


def normalize_keyword(text: str) -> str:
    cleaned = (text or "").replace("\ufeff", "").replace("\u200b", "").replace("\u200c", "").replace("\u200d", "")
    cleaned = cleaned.replace("\xa0", " ").replace("　", " ").replace("\t", " ")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def read_keywords(path: Path) -> List[str]:
    content = read_text_best_effort(path)
    keywords = []
    for line in content.splitlines():
        kw = normalize_keyword(line)
        if not kw:
            continue
        keywords.append(kw)
    return keywords


def derive_inaccessible_output_path(path: Path) -> Path:
    return path.with_name(f"{path.stem}_不可访问域名{path.suffix}")


def write_csv(path: Path, rows: Sequence[SearchResult]) -> None:
    headers = ["关键词", "状态", "备注"] + [f"第{i}个域名" for i in range(1, 11)] + ["不可访问域名", "访问异常详情"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in rows:
            values = [row.keyword, row.status, row.note] + row.domains[:10]
            values += [""] * (13 - len(values))
            values += ["；".join(row.inaccessible_domains), "；".join(row.inaccessible_details)]
            writer.writerow(values)


def write_inaccessible_csv(output_path: Path, rows: Sequence[SearchResult]) -> None:
    target = derive_inaccessible_output_path(output_path)
    with target.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["关键词", "不可访问域名", "异常详情"])
        for row in rows:
            for idx, domain in enumerate(row.inaccessible_domains):
                detail = row.inaccessible_details[idx] if idx < len(row.inaccessible_details) else ""
                writer.writerow([row.keyword, domain, detail])


def merge_unique_strings(existing: Sequence[str], new_items: Sequence[str]) -> List[str]:
    out = []
    seen = set()
    for item in list(existing) + list(new_items):
        key = (item or "").strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append((item or "").strip().lower())
    return out


def extract_host(url: str) -> str:
    try:
        host = urlsplit(url).hostname or ""
    except Exception:
        return ""
    return host.strip().lower().rstrip(".")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def safe_int(value: object, default: int = 0) -> int:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def dedupe_strings(items: Iterable[str]) -> List[str]:
    seen = set()
    out = []
    for item in items:
        key = (item or "").strip()
        if not key:
            continue
        norm = key.lower()
        if norm in seen:
            continue
        seen.add(norm)
        out.append(key)
    return out


def main() -> None:
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
