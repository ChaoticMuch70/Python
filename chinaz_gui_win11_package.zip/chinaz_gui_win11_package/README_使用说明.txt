【这个包是什么】
这是“站长之家移动端权重批量查询”的 Windows 11 图形界面版源码包。
你可以直接用 Python 运行，也可以在你自己的 Windows 11 电脑上一键打包成 EXE。

【包内文件】
1. chinaz_mobile_weight_gui.py      图形界面主程序
2. domains.txt                      示例域名列表
3. requirements.txt                 依赖列表
4. run_gui.bat                      直接运行 GUI 程序
5. build_gui_exe.bat                一键打包 GUI EXE
6. README_使用说明.txt              当前说明文件

【直接运行 GUI】
1. 先安装 Google Chrome。
2. 再安装 Python 3.11 或更高版本。
3. 双击 run_gui.bat。
4. 在窗口里粘贴域名，或点击“从文件载入”。
5. 点击“开始查询”。
6. 结果会保存成 CSV，日志会写入 domain_rank.log。

【打包成 EXE】
1. 在 Windows 11 上双击 build_gui_exe.bat。
2. 首次执行会自动创建虚拟环境并安装依赖。
3. 打包成功后，生成文件在：
   dist\站长之家移动权重批量查询.exe

【程序功能】
1. 支持直接粘贴域名，一行一个。
2. 支持从 txt 文件载入域名。
3. 支持选择结果 CSV 保存位置。
4. 支持查看实时日志和进度条。
5. 默认使用“可见浏览器”模式，更稳。
6. 可选“无头模式”，但部分情况下更容易触发风控。

【重要说明】
1. 这是抓取“移动端权重”的修正版，不是你之前的旧脚本原样封装。
2. 站长之家页面如果再次改版，抓取逻辑仍可能需要继续调整。
3. 如果页面出现验证码、风控、重定向，程序可能失败，这是目标站点行为，不是 GUI 本身的语法错误。
4. Selenium 4 通常会自动管理 ChromeDriver，所以一般不需要你手动下载驱动。

【失败时优先检查】
1. Google Chrome 是否已正确安装。
2. 网络是否可访问 rank.chinaz.com。
3. 是否出现验证码或访问频率限制。
4. domain_rank.log 里最后几行的报错内容。
