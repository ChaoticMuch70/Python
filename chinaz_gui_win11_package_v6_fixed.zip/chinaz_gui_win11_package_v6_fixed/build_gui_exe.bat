@echo off
setlocal
powershell -ExecutionPolicy Bypass -File "%~dp0build_gui_exe.ps1"
endlocal
