Quick start (Windows 11)

1. Install Google Chrome.
2. Install Python 3.11 and verify in PowerShell:
   python --version
3. Open PowerShell in this folder.
4. Run the GUI:
   .\run_gui.ps1
5. Build the EXE:
   .\build_gui_exe.ps1
6. After build completes, the EXE is here:
   dist\chinaz_mobile_weight_checker.exe

Notes:
- These PowerShell scripts use only ASCII text to avoid encoding problems.
- They call .venv\Scripts\python.exe directly, so activation policy issues are avoided.


Update v5:
- Fixed mobile rank extraction logic.
- The program now anchors on the exact label "移动端" inside the mobile section and takes the first baidu*.png after that label, instead of scanning the whole section.
- If extraction still fails, it saves HTML to debug_html/<domain>.html for troubleshooting.
