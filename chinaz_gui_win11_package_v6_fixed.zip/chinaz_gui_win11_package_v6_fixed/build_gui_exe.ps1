$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$exeName = 'chinaz_mobile_weight_checker'

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "python command not found. Install Python 3.11 and make sure 'python --version' works in PowerShell." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    python -m venv .venv
}

& ".\.venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
& ".\.venv\Scripts\python.exe" -m pip install pyinstaller

if (Test-Path '.\build') { Remove-Item '.\build' -Recurse -Force }
if (Test-Path '.\dist') { Remove-Item '.\dist' -Recurse -Force }
if (Test-Path ".\$exeName.spec") { Remove-Item ".\$exeName.spec" -Force }

& ".\.venv\Scripts\python.exe" -m PyInstaller `
  --noconfirm `
  --clean `
  --windowed `
  --onefile `
  --name $exeName `
  --collect-all selenium `
  .\chinaz_mobile_weight_gui.py

Write-Host ""
Write-Host "Build completed. EXE path: dist\\$exeName.exe" -ForegroundColor Green
Read-Host "Press Enter to exit"
