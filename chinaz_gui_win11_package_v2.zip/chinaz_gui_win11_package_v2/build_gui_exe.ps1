$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host '未检测到 python 命令。请先安装 Python 3.11，并确认在 PowerShell 中运行 python --version 正常。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}

if (-not (Test-Path '.venv\Scripts\python.exe')) {
    python -m venv .venv
}

& '.\.venv\Scripts\Activate.ps1'
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if (Test-Path '.\build') { Remove-Item '.\build' -Recurse -Force }
if (Test-Path '.\dist') { Remove-Item '.\dist' -Recurse -Force }
if (Test-Path '.\站长之家移动权重批量查询.spec') { Remove-Item '.\站长之家移动权重批量查询.spec' -Force }

python -m PyInstaller --noconfirm --clean --windowed --onefile --name '站长之家移动权重批量查询' .\chinaz_mobile_weight_gui.py
Write-Host ''
Write-Host '打包完成。EXE 路径：dist\站长之家移动权重批量查询.exe' -ForegroundColor Green
Read-Host '按回车退出'
