【这是修正版 v2，建议只用 PowerShell 运行】

一、你当前环境的关键判断
1. 你的 Python 已经安装正常。
2. 你的普通 cmd 存在 AutoRun 干扰，因此不要把本项目建立在普通 cmd 上。
3. 后续请统一使用 PowerShell，避免反复踩同一个坑。

二、第一次运行前要准备的东西
1. 安装 Google Chrome。
2. 在 PowerShell 中确认：python --version 能正常输出版本号。
3. 保证网络可以访问站长之家。

三、运行 GUI
方法 A（推荐）
1. 在本文件夹空白处按住 Shift + 鼠标右键。
2. 选择“在此处打开 PowerShell 窗口”。
3. 执行：
   .\run_gui.ps1

方法 B
直接双击 run_gui.bat。
如果双击没有成功，仍然回到方法 A。

四、打包 EXE
1. 在本文件夹打开 PowerShell。
2. 执行：
   .\build_gui_exe.ps1
3. 打包完成后，EXE 在：
   .\dist\站长之家移动权重批量查询.exe

五、常见问题
1. 如果 PowerShell 提示脚本被禁止执行，请先执行：
   Set-ExecutionPolicy -Scope Process Bypass
   然后再运行 .\run_gui.ps1 或 .\build_gui_exe.ps1

2. 如果 Chrome 启动失败，请先确认本机已安装 Google Chrome。

3. 如果查询时页面被拦截、验证码或无数据，这是站长之家页面风控或页面变动，不是 Python 环境问题。

4. 如果你以后重装 Python，只要保证 PowerShell 里 python --version 正常，本项目基本就能继续运行。

六、最稳的长期使用方式
1. 以后只用 PowerShell 运行本项目。
2. 不依赖普通 cmd。
3. 不手动删除 .venv，除非依赖损坏。
4. 打包和运行都使用当前目录内的脚本。
