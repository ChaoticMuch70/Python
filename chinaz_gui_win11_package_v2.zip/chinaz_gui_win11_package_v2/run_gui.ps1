$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host '未检测到 python 命令。请先安装 Python 3.11，并确认在 PowerShell 中运行 python --version 正常。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}

if (-not (Test-Path '.venv\Scripts\python.exe')) {
    python -m venv .venv
}

& '.\.venv\Scripts\Activate.ps1'
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python .\chinaz_mobile_weight_gui.py
Read-Host '程序已退出，按回车关闭窗口'
