# -*- coding: utf-8 -*-
import csv
import os
import queue
import re
import sys
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Optional, Tuple
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "网页标题关键词筛选工具"
DEFAULT_TIMEOUT = 10
DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
}


@dataclass
class ResultRow:
    域名: str
    原始输入: str
    访问URL: str
    最终URL: str
    状态: str
    HTTP状态码: str
    标题: str
    命中关键词: str
    错误信息: str
    处理时间: str


def app_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def read_text_file(path: str) -> str:
    encodings = ["utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16", "utf-16-le", "utf-16-be"]
    last_error = None
    for enc in encodings:
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except Exception as e:
            last_error = e
    raise last_error if last_error else RuntimeError("无法读取文件")


def parse_domains_from_text(text: str) -> List[str]:
    lines = []
    for raw in text.splitlines():
        line = raw.replace("\ufeff", "").replace("\u200b", "").strip()
        if not line:
            continue
        lines.append(line)
    return lines


def split_keywords(text: str) -> List[str]:
    items = re.split(r"[,，]", text or "")
    keywords = []
    seen = set()
    for item in items:
        kw = item.strip()
        if not kw:
            continue
        key = kw.casefold()
        if key not in seen:
            seen.add(key)
            keywords.append(kw)
    return keywords


def normalize_domain_or_url(raw: str) -> Tuple[str, List[str]]:
    raw = (raw or "").strip()
    if not raw:
        return "", []

    # Remove surrounding punctuation that often appears in pasted lists.
    raw = raw.strip(" \t\r\n\"'“”‘’<>（）()[]{}，,。；;：:")
    if not raw:
        return "", []

    candidates: List[str] = []
    if raw.startswith("http://") or raw.startswith("https://"):
        parsed = urlparse(raw)
        host = (parsed.netloc or parsed.path).strip().lower()
        host = host.lstrip("/")
        host = host.split(":")[0]
        if not host:
            return "", []
        candidates.append(raw)
        domain = host
    else:
        domain = raw.lower().strip("/")
        if "/" in domain:
            domain = domain.split("/")[0]
        domain = domain.split(":")[0]
        if not domain:
            return "", []
        candidates.extend([f"https://{domain}", f"http://{domain}"])
        if not domain.startswith("www."):
            candidates.extend([f"https://www.{domain}", f"http://www.{domain}"])

    # Deduplicate while keeping order.
    deduped = []
    seen = set()
    for url in candidates:
        if url not in seen:
            seen.add(url)
            deduped.append(url)
    return domain, deduped


class TitleFetcher:
    def __init__(self, timeout: int = DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.session = requests.Session()
        retry = Retry(
            total=2,
            connect=2,
            read=2,
            backoff_factor=0.6,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"],
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        self.session.headers.update(DEFAULT_HEADERS)

    def close(self):
        try:
            self.session.close()
        except Exception:
            pass

    def fetch_title(self, raw_input: str) -> ResultRow:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        domain, urls = normalize_domain_or_url(raw_input)
        if not domain or not urls:
            return ResultRow(domain or raw_input, raw_input, "", "", "失败", "", "", "", "输入无效", now)

        last_error = ""
        for url in urls:
            try:
                resp = self.session.get(url, timeout=self.timeout, allow_redirects=True, verify=False)
                status_code = str(resp.status_code)
                content_type = (resp.headers.get("Content-Type") or "").lower()
                if "text/html" not in content_type and "application/xhtml+xml" not in content_type:
                    # Some sites omit proper content-type, still try when body looks like HTML.
                    sample = resp.text[:500].lower() if resp.text else ""
                    if "<html" not in sample and "<title" not in sample:
                        last_error = f"非HTML页面: {content_type or '未知类型'}"
                        continue

                title = self._extract_title(resp)
                if title:
                    return ResultRow(
                        域名=domain,
                        原始输入=raw_input,
                        访问URL=url,
                        最终URL=resp.url,
                        状态="成功",
                        HTTP状态码=status_code,
                        标题=title,
                        命中关键词="",
                        错误信息="",
                        处理时间=now,
                    )
                last_error = "页面无标题"
            except requests.RequestException as e:
                last_error = str(e)
            except Exception as e:
                last_error = str(e)
        return ResultRow(domain, raw_input, urls[0] if urls else "", "", "失败", "", "", "", last_error or "访问失败", now)

    @staticmethod
    def _extract_title(resp: requests.Response) -> str:
        if not resp.content:
            return ""

        # requests will guess encoding; repair when missing.
        if not resp.encoding or resp.encoding.lower() == "iso-8859-1":
            apparent = getattr(resp, "apparent_encoding", None)
            if apparent:
                resp.encoding = apparent

        html = resp.text or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "html.parser")
        if soup.title and soup.title.string:
            title = soup.title.string.strip()
            if title:
                return re.sub(r"\s+", " ", title)

        m = re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.I | re.S)
        if m:
            title = re.sub(r"<[^>]+>", "", m.group(1)).strip()
            return re.sub(r"\s+", " ", title)
        return ""


def match_keywords(title: str, keywords: List[str]) -> List[str]:
    if not title or not keywords:
        return []
    title_cf = title.casefold()
    matched = []
    for kw in keywords:
        kw_cf = kw.casefold()
        if kw_cf in title_cf:
            matched.append(kw)
    return matched


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1080x760")

        self.log_queue: queue.Queue[str] = queue.Queue()
        self.fetcher = TitleFetcher()
        self.worker_thread: Optional[threading.Thread] = None
        self.pause_event = threading.Event()
        self.stop_event = threading.Event()
        self.running = False
        self.results: List[ResultRow] = []
        self.current_index = 0
        self.total_count = 0
        self.output_csv_path = tk.StringVar(value=os.path.join(app_dir(), "标题关键词筛选结果.csv"))
        self.domain_file_path = tk.StringVar(value="")
        self.timeout_var = tk.StringVar(value=str(DEFAULT_TIMEOUT))
        self.status_var = tk.StringVar(value="状态：未开始")
        self.progress_var = tk.StringVar(value="进度：0/0")

        self._build_ui()
        self._poll_log_queue()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        top_frame = ttk.Frame(self.root, padding=10)
        top_frame.pack(fill="x")

        row1 = ttk.Frame(top_frame)
        row1.pack(fill="x", pady=4)
        ttk.Label(row1, text="域名文件：").pack(side="left")
        ttk.Entry(row1, textvariable=self.domain_file_path).pack(side="left", fill="x", expand=True, padx=5)
        ttk.Button(row1, text="选择TXT", command=self.choose_domain_file).pack(side="left", padx=5)
        ttk.Button(row1, text="载入到下方", command=self.load_domain_file).pack(side="left")

        row2 = ttk.Frame(top_frame)
        row2.pack(fill="x", pady=4)
        ttk.Label(row2, text="关键词（逗号分隔）：").pack(side="left")
        self.keyword_entry = ttk.Entry(row2)
        self.keyword_entry.pack(side="left", fill="x", expand=True, padx=5)
        ttk.Label(row2, text="超时秒数：").pack(side="left", padx=(10, 0))
        ttk.Entry(row2, width=8, textvariable=self.timeout_var).pack(side="left", padx=5)

        row3 = ttk.Frame(top_frame)
        row3.pack(fill="x", pady=4)
        ttk.Label(row3, text="结果CSV：").pack(side="left")
        ttk.Entry(row3, textvariable=self.output_csv_path).pack(side="left", fill="x", expand=True, padx=5)
        ttk.Button(row3, text="选择保存位置", command=self.choose_output_path).pack(side="left")

        ttk.Label(top_frame, text="域名列表（每行一个域名或URL）：").pack(anchor="w", pady=(8, 2))
        self.domain_text = tk.Text(top_frame, height=10, wrap="word")
        self.domain_text.pack(fill="x")

        button_row = ttk.Frame(top_frame)
        button_row.pack(fill="x", pady=8)
        ttk.Button(button_row, text="开始", command=self.start_task).pack(side="left", padx=4)
        ttk.Button(button_row, text="暂停", command=self.pause_task).pack(side="left", padx=4)
        ttk.Button(button_row, text="继续", command=self.resume_task).pack(side="left", padx=4)
        ttk.Button(button_row, text="停止", command=self.stop_task).pack(side="left", padx=4)
        ttk.Button(button_row, text="导出当前结果", command=self.export_current_results).pack(side="left", padx=20)
        ttk.Button(button_row, text="清空结果", command=self.clear_results).pack(side="left", padx=4)

        status_row = ttk.Frame(top_frame)
        status_row.pack(fill="x", pady=4)
        ttk.Label(status_row, textvariable=self.status_var).pack(side="left")
        ttk.Label(status_row, textvariable=self.progress_var).pack(side="right")

        self.progress = ttk.Progressbar(top_frame, orient="horizontal", mode="determinate")
        self.progress.pack(fill="x", pady=4)

        result_frame = ttk.LabelFrame(self.root, text="结果预览", padding=10)
        result_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        columns = ("域名", "状态", "标题", "命中关键词", "错误信息")
        self.tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=12)
        for col, width in [("域名", 180), ("状态", 80), ("标题", 480), ("命中关键词", 160), ("错误信息", 180)]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True)

        log_frame = ttk.LabelFrame(self.root, text="运行日志", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.log_text = tk.Text(log_frame, height=10, wrap="word")
        self.log_text.pack(fill="both", expand=True)

    def choose_domain_file(self):
        path = filedialog.askopenfilename(
            title="选择域名TXT文件",
            filetypes=[("文本文件", "*.txt"), ("CSV文件", "*.csv"), ("所有文件", "*.*")],
        )
        if path:
            self.domain_file_path.set(path)

    def load_domain_file(self):
        path = self.domain_file_path.get().strip()
        if not path:
            messagebox.showwarning("提示", "请先选择域名文件。")
            return
        try:
            text = read_text_file(path)
            self.domain_text.delete("1.0", tk.END)
            self.domain_text.insert("1.0", text)
            self.log(f"已载入文件：{path}")
        except Exception as e:
            messagebox.showerror("错误", f"读取文件失败：{e}")

    def choose_output_path(self):
        path = filedialog.asksaveasfilename(
            title="选择结果CSV保存位置",
            defaultextension=".csv",
            initialfile="标题关键词筛选结果.csv",
            filetypes=[("CSV文件", "*.csv")],
        )
        if path:
            self.output_csv_path.set(path)

    def start_task(self):
        if self.running:
            messagebox.showinfo("提示", "任务已经在运行中。")
            return
        keywords = split_keywords(self.keyword_entry.get())
        if not keywords:
            messagebox.showwarning("提示", "请输入关键词，多个关键词请用逗号分隔。")
            return
        domains = parse_domains_from_text(self.domain_text.get("1.0", tk.END))
        if not domains:
            messagebox.showwarning("提示", "请先输入或载入域名列表。")
            return

        try:
            timeout = int(self.timeout_var.get().strip())
            if timeout < 3:
                timeout = 3
        except Exception:
            timeout = DEFAULT_TIMEOUT
            self.timeout_var.set(str(timeout))

        self.fetcher.close()
        self.fetcher = TitleFetcher(timeout=timeout)
        self.results = []
        self.current_index = 0
        self.total_count = len(domains)
        self.progress.configure(maximum=self.total_count, value=0)
        self.progress_var.set(f"进度：0/{self.total_count}")
        self.status_var.set("状态：运行中")
        self.tree.delete(*self.tree.get_children())
        self.pause_event.set()
        self.stop_event.clear()
        self.running = True

        output_path = self.output_csv_path.get().strip()
        self.log(f"开始处理，共 {len(domains)} 个域名，关键词：{', '.join(keywords)}")
        self.worker_thread = threading.Thread(
            target=self._worker,
            args=(domains, keywords, output_path),
            daemon=True,
        )
        self.worker_thread.start()

    def pause_task(self):
        if not self.running:
            return
        self.pause_event.clear()
        self.status_var.set("状态：已暂停")
        self.log("已暂停。")

    def resume_task(self):
        if not self.running:
            return
        self.pause_event.set()
        self.status_var.set("状态：运行中")
        self.log("已继续。")

    def stop_task(self):
        if not self.running:
            return
        self.stop_event.set()
        self.pause_event.set()
        self.status_var.set("状态：正在停止")
        self.log("收到停止指令，当前域名处理完后停止。")

    def clear_results(self):
        if self.running:
            messagebox.showwarning("提示", "请先停止当前任务。")
            return
        self.results = []
        self.tree.delete(*self.tree.get_children())
        self.log_text.delete("1.0", tk.END)
        self.status_var.set("状态：未开始")
        self.progress_var.set("进度：0/0")
        self.progress.configure(maximum=0, value=0)

    def export_current_results(self):
        if not self.results:
            messagebox.showinfo("提示", "当前还没有可导出的结果。")
            return
        path = self.output_csv_path.get().strip()
        if not path:
            path = filedialog.asksaveasfilename(
                title="选择结果CSV保存位置",
                defaultextension=".csv",
                initialfile="标题关键词筛选结果.csv",
                filetypes=[("CSV文件", "*.csv")],
            )
            if not path:
                return
            self.output_csv_path.set(path)
        try:
            self._save_results(path)
            messagebox.showinfo("提示", f"已导出当前结果：{path}")
        except Exception as e:
            messagebox.showerror("错误", f"导出失败：{e}")

    def _worker(self, domains: List[str], keywords: List[str], output_path: str):
        try:
            for index, raw in enumerate(domains, start=1):
                if self.stop_event.is_set():
                    break
                while not self.pause_event.is_set():
                    if self.stop_event.is_set():
                        break
                    time.sleep(0.2)
                if self.stop_event.is_set():
                    break

                row = self.fetcher.fetch_title(raw)
                matched = match_keywords(row.标题, keywords)
                row.命中关键词 = "|".join(matched)
                self.results.append(row)
                self.current_index = index
                self.progress["value"] = index
                self.progress_var.set(f"进度：{index}/{self.total_count}")
                self.tree.insert("", tk.END, values=(row.域名, row.状态, row.标题, row.命中关键词, row.错误信息))
                self.log(
                    f"[{index}/{self.total_count}] {row.原始输入} -> 状态：{row.状态}"
                    f"；标题：{row.标题[:80] if row.标题 else '无'}"
                    f"；命中：{row.命中关键词 or '无'}"
                )
                if output_path:
                    try:
                        self._save_results(output_path)
                    except Exception as e:
                        self.log(f"自动保存失败：{e}")
                time.sleep(0.15)
        finally:
            if output_path and self.results:
                try:
                    self._save_results(output_path)
                except Exception as e:
                    self.log(f"最终保存失败：{e}")
            self.running = False
            if self.stop_event.is_set():
                self.status_var.set("状态：已停止")
                self.log("任务已停止。")
            else:
                self.status_var.set("状态：已完成")
                self.log("任务已完成。")

    def _save_results(self, output_path: str):
        os.makedirs(os.path.dirname(output_path) or app_dir(), exist_ok=True)
        all_rows = [asdict(r) for r in self.results]
        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(ResultRow.__annotations__.keys()))
            writer.writeheader()
            writer.writerows(all_rows)

        matched_path = self._matched_output_path(output_path)
        matched_rows = [asdict(r) for r in self.results if r.命中关键词]
        with open(matched_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(ResultRow.__annotations__.keys()))
            writer.writeheader()
            writer.writerows(matched_rows)

    @staticmethod
    def _matched_output_path(output_path: str) -> str:
        base, ext = os.path.splitext(output_path)
        return f"{base}_命中关键词域名{ext or '.csv'}"

    def log(self, message: str):
        self.log_queue.put(f"[{datetime.now().strftime('%H:%M:%S')}] {message}\n")

    def _poll_log_queue(self):
        while True:
            try:
                msg = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_text.insert(tk.END, msg)
            self.log_text.see(tk.END)
        self.root.after(200, self._poll_log_queue)

    def on_close(self):
        if self.running:
            if not messagebox.askyesno("确认", "任务仍在运行，确认退出吗？"):
                return
            self.stop_event.set()
            self.pause_event.set()
        self.fetcher.close()
        self.root.destroy()


if __name__ == "__main__":
    # Avoid SSL warnings for sites with certificate issues; stability first.
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "vista" in style.theme_names():
            style.theme_use("vista")
    except Exception:
        pass
    app = App(root)
    root.mainloop()
