@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0build_gui_exe.ps1"
