import csv
import json
import os
import queue
import random
import re
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple
from urllib.parse import parse_qs, quote, unquote, urljoin, urlsplit, urlparse
from html import unescape

import requests
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

APP_TITLE = "百度移动搜索前10域名提取工具"
DEFAULT_OUTPUT = "百度移动搜索前10域名.csv"
DEFAULT_LOG = "百度移动搜索前10域名.log"
DEFAULT_KEYWORDS = "keywords.txt"
MAX_RESULTS = 10
MAX_PAGES = 5

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
)

EXCLUDED_HOST_KEYWORDS = {
    "m.baidu.com",
    "www.baidu.com",
    "passport.baidu.com",
    "voice.baidu.com",
    "smartapp.baidu.com",
    "34689.recommend_list.baidu.com",
    "28330.recommend_list.baidu.com",
    "fakeurl.ubs.baidu.com",
    "nourl.ubs.baidu.com",
}

SKIP_RESULT_SRCIDS = {
    "recommend_list_san",
    "user_monitor_cards",
    "note_lead",
    "lego_tpl",
    "fw_recommend",
    "poi_multi_san",
    "b2b_prod_recomm",
    "b2b_factory_wise_san",
}

SKIP_TEXT_PATTERNS = [
    "大家还在搜",
    "这次搜索你觉得满意吗",
    "百度APP内打开",
    "相关服务推荐",
    "相关商品推荐",
    "地址、电话、用户评价",
    "爱企查企业服务",
    "精选厂家",
]

RESULT_SELECTORS = [
    "div.result h3 a[href]",
    "div[class*='result'] h3 a[href]",
    "div[class*='c-result'] h3 a[href]",
    "div[data-log] h3 a[href]",
    "article h3 a[href]",
    "h3 a[href]",
    "a[data-module][href]",
]


def get_app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = get_app_dir()
LOG_PATH = APP_DIR / DEFAULT_LOG
DEBUG_DIR = APP_DIR / "debug_html"


class Logger:
    def __init__(self, callback=None):
        self.callback = callback

    def write(self, message: str) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {message}"
        try:
            with LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        if self.callback:
            self.callback(line)


@dataclass
class SearchResult:
    keyword: str
    domains: List[str]
    status: str
    note: str = ""


@dataclass
class ParsedCard:
    order: int
    srcid: str
    tpl: str
    text: str
    url: str


class DomainExtractor:
    def __init__(self, logger: Logger, headless: bool = True, delay: float = 1.5, save_html: bool = False):
        self.logger = logger
        self.headless = headless
        self.delay = max(0.0, delay)
        self.save_html = save_html
        self.driver: Optional[webdriver.Chrome] = None
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "zh-CN,zh;q=0.9",
        })

    def start(self) -> None:
        options = Options()
        mobile_emulation = {
            "deviceMetrics": {"width": 412, "height": 915, "pixelRatio": 2.625},
            "userAgent": USER_AGENT,
        }
        options.add_experimental_option("mobileEmulation", mobile_emulation)
        options.add_argument("--lang=zh-CN")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=430,960")
        if self.headless:
            options.add_argument("--headless=new")
        self.driver = webdriver.Chrome(service=Service(), options=options)
        self.driver.set_page_load_timeout(45)
        self.logger.write("Chrome 浏览器驱动已启动。")

    def close(self) -> None:
        try:
            if self.driver:
                self.driver.quit()
        except Exception:
            pass
        self.driver = None

    def search_keyword(self, keyword: str) -> SearchResult:
        assert self.driver is not None, "Driver not started"
        query = normalize_keyword(keyword)
        if not query:
            return SearchResult(keyword="", domains=[], status="跳过", note="空关键词")

        self.logger.write(f"开始搜索关键词：{query}")
        all_domains: List[str] = []
        visited_page_urls = set()
        next_url = f"https://m.baidu.com/s?word={quote(query)}"

        for page_index in range(1, MAX_PAGES + 1):
            if not next_url or next_url in visited_page_urls:
                break
            visited_page_urls.add(next_url)

            try:
                self.driver.get(next_url)
                self._wait_for_page_ready()
                time.sleep(self.delay + random.uniform(0.4, 1.2))
            except TimeoutException:
                self.logger.write(f"页面加载超时：{query}（第 {page_index} 页）")
            except WebDriverException as exc:
                return SearchResult(keyword=query, domains=[], status="错误", note=f"浏览器错误：{exc}")

            self._try_expand_results()
            html = self.driver.page_source
            current_url = self.driver.current_url
            page_title = self.driver.title or ""

            if self.save_html:
                self._save_debug_html(query, html, suffix=f"_第{page_index}页")

            if self._looks_like_blocked(html, current_url, page_title):
                self._save_debug_html(query, html, suffix=f"_第{page_index}页_拦截")
                return SearchResult(keyword=query, domains=all_domains[:MAX_RESULTS], status="被拦截", note="百度可能触发了验证或访问限制")

            page_domains = self._extract_domains_from_result_cards(html)
            if not page_domains:
                anchors = self._collect_candidate_anchors()
                if not anchors:
                    anchors = self._extract_candidate_anchors_from_html(html, current_url)
                page_domains = self._resolve_domains(anchors)

            if page_domains:
                self.logger.write(f"第 {page_index} 页提取到 {len(page_domains)} 个候选域名。")
                all_domains = merge_unique_strings(all_domains, page_domains)
                self.logger.write(f"当前累计唯一域名 {len(all_domains)} 个。")
            else:
                self.logger.write(f"第 {page_index} 页未提取到有效域名。")

            if len(all_domains) >= MAX_RESULTS:
                break

            next_url = self._extract_next_page_url(html, current_url, query, page_index)
            if next_url:
                self.logger.write(f"准备继续抓取第 {page_index + 1} 页。")

        if not all_domains:
            self._save_debug_html(query, self.driver.page_source, suffix="_未提取到结果")
            return SearchResult(keyword=query, domains=[], status="失败", note="未提取到有效域名")

        domains = all_domains[:MAX_RESULTS]
        if len(domains) < MAX_RESULTS:
            note = f"仅提取到 {len(domains)} 个唯一域名（已自动翻页补足）"
            status = "部分成功"
        else:
            note = f"已提取前 {MAX_RESULTS} 个域名"
            status = "成功"
        return SearchResult(keyword=query, domains=domains, status=status, note=note)

    def _wait_for_page_ready(self) -> None:
        assert self.driver is not None
        wait = WebDriverWait(self.driver, 20)
        try:
            wait.until(lambda d: d.execute_script("return document.readyState") == "complete")
        except TimeoutException:
            pass
        selectors = [
            "div.c-result.result[order]",
            "#results div.c-result.result",
            "h3 a[href]",
            "div.result",
            "div[class*='result']",
            "body",
        ]
        for selector in selectors:
            try:
                wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                return
            except TimeoutException:
                continue

    def _try_expand_results(self) -> None:
        assert self.driver is not None
        candidates = [
            "查看更多",
            "展开更多",
            "显示更多",
            "下一页",
            "加载更多",
        ]
        try:
            buttons = self.driver.find_elements(By.XPATH, "//a|//button|//div")
        except Exception:
            return
        for btn in buttons[:200]:
            try:
                text = (btn.text or "").strip()
                if text in candidates:
                    self.driver.execute_script("arguments[0].click();", btn)
                    time.sleep(1.0)
                    break
            except Exception:
                continue

    def _looks_like_blocked(self, html: str, current_url: str, page_title: str) -> bool:
        signals = [current_url, page_title, html[:5000]]
        joined = "\n".join(s for s in signals if s).lower()
        patterns = [
            "验证码",
            "安全验证",
            "请完成以下验证",
            "请输入验证码",
            "访问受限",
            "network anomaly",
            "captcha",
            "antirobot",
        ]
        return any(p.lower() in joined for p in patterns)

    def _extract_domains_from_result_cards(self, html: str) -> List[str]:
        cards = self._parse_result_cards(html)
        if cards:
            self.logger.write(f"从渲染后的页面中解析到 {len(cards)} 个结果卡片。")
        domains: List[str] = []
        for card in cards:
            host = extract_host(card.url)
            if not host:
                continue
            if self._should_skip_host(host, card.text):
                continue
            if host not in domains:
                domains.append(host)
        return domains

    def _parse_result_cards(self, html: str) -> List[ParsedCard]:
        soup = BeautifulSoup(html, "html.parser")
        raw_cards = soup.select("#results div.c-result.result[order]") or soup.select("div.c-result.result[order]")
        parsed: List[ParsedCard] = []
        for res in raw_cards:
            card = self._parse_single_result_card(res)
            if card:
                parsed.append(card)
        parsed.sort(key=lambda x: (x.order, x.text))
        return parsed

    def _parse_single_result_card(self, res) -> Optional[ParsedCard]:
        order = safe_int(res.get("order"), default=999999)
        srcid = (res.get("srcid") or "").strip()
        tpl = (res.get("tpl") or "").strip()
        text = normalize_text(res.get_text(" ", strip=True))

        if self._should_skip_result_card(srcid=srcid, tpl=tpl, text=text):
            return None

        candidate_urls = self._extract_candidate_urls_from_card(res)
        for url in candidate_urls:
            host = extract_host(url)
            if not host:
                continue
            if host in EXCLUDED_HOST_KEYWORDS:
                continue
            if host.endswith("recommend_list.baidu.com") or host.endswith("ubs.baidu.com"):
                continue
            return ParsedCard(order=order, srcid=srcid, tpl=tpl, text=text, url=url)
        return None

    def _extract_candidate_urls_from_card(self, res) -> List[str]:
        urls: List[str] = []

        data_log = res.get("data-log")
        if data_log:
            try:
                mu = json.loads(data_log).get("mu")
                if isinstance(mu, str) and mu.strip():
                    urls.append(mu.strip())
            except Exception:
                pass

        for tag in res.find_all(True):
            for attr_name, attr_value in tag.attrs.items():
                if not isinstance(attr_value, str):
                    continue
                lower_name = attr_name.lower()
                value = attr_value.strip()
                if not value:
                    continue
                if lower_name == "rl-link-data-click":
                    extra_url = self._extract_url_from_rl_click(value)
                    if extra_url:
                        urls.append(extra_url)
                elif lower_name in {"rl-link-data-url", "data-url", "href"}:
                    direct = self._clean_candidate_url(value)
                    if direct:
                        urls.append(direct)

        return dedupe_strings(urls)

    def _extract_url_from_rl_click(self, raw: str) -> str:
        try:
            data = json.loads(raw)
        except Exception:
            return ""
        extra = data.get("extra")
        if isinstance(extra, str):
            try:
                extra = json.loads(extra)
            except Exception:
                extra = None
        if isinstance(extra, dict):
            for key in ("url", "dataUrl"):
                value = extra.get(key)
                cleaned = self._clean_candidate_url(value)
                if cleaned:
                    return cleaned
        return ""

    def _clean_candidate_url(self, value: object) -> str:
        if not isinstance(value, str):
            return ""
        text = value.strip()
        if not text:
            return ""
        for _ in range(3):
            decoded = unquote(text)
            if decoded == text:
                break
            text = decoded
        if text.startswith("http://") or text.startswith("https://"):
            return text
        return ""

    def _should_skip_result_card(self, srcid: str, tpl: str, text: str) -> bool:
        if srcid in SKIP_RESULT_SRCIDS or tpl in SKIP_RESULT_SRCIDS:
            return True
        normalized = text.replace(" ", "")
        leading = normalized[:40]
        if any(leading.startswith(pattern.replace(" ", "")) for pattern in SKIP_TEXT_PATTERNS):
            return True
        if not text:
            return True
        return False

    def _collect_candidate_anchors(self) -> List[Tuple[str, str]]:
        assert self.driver is not None
        js = r'''
        const selectors = arguments[0];
        const seen = new Set();
        const items = [];
        for (const selector of selectors) {
          document.querySelectorAll(selector).forEach(a => {
            if (!a || !a.href) return;
            if (seen.has(a)) return;
            seen.add(a);
            const text = (a.innerText || a.textContent || '').trim();
            items.push({href: a.href, text});
          });
        }
        return items;
        '''
        items = []
        try:
            raw = self.driver.execute_script(js, RESULT_SELECTORS) or []
        except Exception:
            raw = []

        for item in raw:
            href = (item.get("href") or "").strip()
            text = (item.get("text") or "").strip()
            if self._is_candidate_anchor(href, text):
                items.append((href, text))
        return self._dedupe_preserve_order(items)

    def _extract_candidate_anchors_from_html(self, html: str, current_url: str) -> List[Tuple[str, str]]:
        soup = BeautifulSoup(html, "html.parser")
        items: List[Tuple[str, str]] = []
        selectors = [
            "div.result h3 a[href]",
            "div[class*='result'] h3 a[href]",
            "div[data-log] h3 a[href]",
            "h3 a[href]",
        ]
        for selector in selectors:
            for a in soup.select(selector):
                href = urljoin(current_url, (a.get("href") or "").strip())
                text = a.get_text(" ", strip=True)
                if self._is_candidate_anchor(href, text):
                    items.append((href, text))
        return self._dedupe_preserve_order(items)

    def _is_candidate_anchor(self, href: str, text: str) -> bool:
        if not href:
            return False
        href_l = href.lower()
        if href_l.startswith(("javascript:", "mailto:", "tel:")):
            return False
        if href_l.startswith("#"):
            return False
        bad_parts = [
            "passport.baidu.com",
            "/from=844b/",
            "voice.baidu.com",
            "image.baidu.com",
            "map.baidu.com",
            "mbd.baidu.com/ma/s/",
            "www.baidu.com/from=",
        ]
        if any(p in href_l for p in bad_parts):
            return False
        bad_text = ["百度一下", "相关搜索", "下一页", "上一页", "更多结果", "使用百度前必读"]
        if text and any(t in text for t in bad_text):
            return False
        return href_l.startswith("http")

    def _resolve_domains(self, anchors: Sequence[Tuple[str, str]]) -> List[str]:
        domains: List[str] = []
        for href, text in anchors:
            final_url = self._resolve_url(href)
            host = extract_host(final_url)
            if not host:
                continue
            if self._should_skip_host(host, text):
                continue
            if host not in domains:
                domains.append(host)
            if len(domains) >= MAX_RESULTS:
                break
        return domains

    def _resolve_url(self, href: str) -> str:
        host = extract_host(href)
        if host and not host.endswith("baidu.com") and not host.endswith("baidu.cn"):
            return href

        try:
            response = self.session.get(href, timeout=15, allow_redirects=True)
            return response.url or href
        except Exception:
            return href

    def _should_skip_host(self, host: str, text: str) -> bool:
        host = host.lower()
        if host in EXCLUDED_HOST_KEYWORDS:
            return True
        if host.endswith("recommend_list.baidu.com") or host.endswith("ubs.baidu.com"):
            return True
        if host.endswith("baidu.com") or host.endswith("baidu.cn"):
            title = (text or "").lower()
            if "百度" not in title and "文心" not in title:
                return True
        return False

    def _extract_next_page_url(self, html: str, current_url: str, query: str, current_page_index: int) -> str:
        next_offset = current_page_index * 10

        regex_patterns = [
            r'href="([^"]*?/s\?[^"]*?pn=%d[^"]*?)"[^>]*>\s*&nbsp;\s*</a><p[^>]*>.*?下一页' % next_offset,
            r'href="([^"]*?/s\?[^"]*?pn=%d[^"]*?sa=np[^"]*?)"' % next_offset,
        ]
        for pattern in regex_patterns:
            match = re.search(pattern, html, flags=re.S)
            if match:
                return urljoin(current_url, unescape(match.group(1)))

        soup = BeautifulSoup(html, "html.parser")
        candidates = []
        for a in soup.find_all("a", href=True):
            href = unescape((a.get("href") or "").strip())
            if not href:
                continue
            full = urljoin(current_url, href)
            if "/s?" not in full or "word=" not in full:
                continue
            parsed = urlparse(full)
            qs = parse_qs(parsed.query)
            try:
                pn = int((qs.get("pn") or ["0"])[0])
            except Exception:
                continue
            if pn < next_offset:
                continue
            text = normalize_text(a.get_text(" ", strip=True))
            score = pn
            if pn == next_offset:
                score -= 1000
            if "sa=np" in full:
                score -= 100
            if "下一页" in text:
                score -= 100
            candidates.append((score, full))

        if candidates:
            candidates.sort(key=lambda item: item[0])
            return candidates[0][1]

        return f"https://m.baidu.com/s?word={quote(query)}&pn={next_offset}"

    def _save_debug_html(self, keyword: str, html: str, suffix: str = "") -> None:
        DEBUG_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^0-9A-Za-z一-鿿._-]+", "_", keyword).strip("._") or "keyword"
        safe_suffix = re.sub(r"[^0-9A-Za-z一-鿿._-]+", "_", suffix).strip("._")
        filename = f"{safe_name}{'_' + safe_suffix if safe_suffix else ''}.html"
        path = DEBUG_DIR / filename
        try:
            path.write_text(html, encoding="utf-8")
            self.logger.write(f"调试 HTML 已保存：{path}")
        except Exception as exc:
            self.logger.write(f"保存调试 HTML 失败：{exc}")

    @staticmethod
    def _dedupe_preserve_order(items: Iterable[Tuple[str, str]]) -> List[Tuple[str, str]]:
        seen = set()
        out = []
        for href, text in items:
            key = (href.strip(), text.strip())
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("960x680")
        self.root.minsize(860, 620)

        self.msg_queue: queue.Queue[Tuple[str, object]] = queue.Queue()
        self.worker: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()

        self.keywords_path = tk.StringVar(value=str(APP_DIR / DEFAULT_KEYWORDS))
        self.output_path = tk.StringVar(value=str(APP_DIR / DEFAULT_OUTPUT))
        self.headless_var = tk.BooleanVar(value=True)
        self.save_html_var = tk.BooleanVar(value=False)
        self.delay_var = tk.StringVar(value="1.5")
        self.status_var = tk.StringVar(value="就绪")
        self.progress_var = tk.DoubleVar(value=0.0)

        self._build_ui()
        self.logger = Logger(self._enqueue_log)
        self.root.after(100, self._process_queue)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        form = ttk.LabelFrame(outer, text="任务设置", padding=12)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="关键词 TXT").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.keywords_path).grid(row=0, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="浏览", command=self._browse_keywords).grid(row=0, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="导出 CSV").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.output_path).grid(row=1, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="浏览", command=self._browse_output).grid(row=1, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="间隔秒数").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.delay_var, width=12).grid(row=2, column=1, sticky="w", pady=6)

        opts = ttk.Frame(form)
        opts.grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Checkbutton(opts, text="无头模式运行 Chrome", variable=self.headless_var).pack(side="left", padx=(0, 18))
        ttk.Checkbutton(opts, text="为每个关键词保存调试 HTML", variable=self.save_html_var).pack(side="left")

        tip = ttk.Label(
            outer,
            text=(
                "TXT 文件格式：一行就是一组关键词。程序会在 m.baidu.com 中搜索每一行，"
                "并尽量提取前 10 个唯一域名导出到 CSV。关键词里可以带标点符号，程序不会按标点拆分。"
            ),
            wraplength=900,
            justify="left",
        )
        tip.pack(fill="x", pady=(10, 8))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 8))
        self.start_btn = ttk.Button(btns, text="开始提取", command=self.start_task)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="当前关键词完成后停止", command=self.stop_task, state="disabled")
        self.stop_btn.pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="打开程序目录", command=self._open_app_folder).pack(side="right")

        progress_frame = ttk.Frame(outer)
        progress_frame.pack(fill="x", pady=(0, 8))
        self.progress = ttk.Progressbar(progress_frame, maximum=100, variable=self.progress_var)
        self.progress.pack(fill="x")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w", pady=(4, 0))

        table_box = ttk.LabelFrame(outer, text="结果预览", padding=8)
        table_box.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table_box, columns=["keyword"] + [f"d{i}" for i in range(1, 11)], show="headings", height=10)
        self.tree.heading("keyword", text="关键词")
        self.tree.column("keyword", width=220, anchor="w")
        for i in range(1, 11):
            col = f"d{i}"
            self.tree.heading(col, text=f"第{i}个域名")
            self.tree.column(col, width=150, anchor="w")
        yscroll = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_box.columnconfigure(0, weight=1)
        table_box.rowconfigure(0, weight=1)

        log_box = ttk.LabelFrame(outer, text="运行日志", padding=8)
        log_box.pack(fill="both", expand=True, pady=(8, 0))
        self.log_text = tk.Text(log_box, height=12, wrap="word")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

    def _browse_keywords(self) -> None:
        path = filedialog.askopenfilename(
            title="选择关键词 TXT 文件",
            filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")],
        )
        if path:
            self.keywords_path.set(path)

    def _browse_output(self) -> None:
        path = filedialog.asksaveasfilename(
            title="选择 CSV 保存位置",
            defaultextension=".csv",
            initialfile=DEFAULT_OUTPUT,
            filetypes=[("CSV 文件", "*.csv")],
        )
        if path:
            self.output_path.set(path)

    def _open_app_folder(self) -> None:
        path = str(APP_DIR)
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo(APP_TITLE, f"程序目录：\n{path}")

    def _enqueue_log(self, line: str) -> None:
        self.msg_queue.put(("log", line))

    def start_task(self) -> None:
        if self.worker and self.worker.is_alive():
            return

        keywords_file = Path(self.keywords_path.get().strip())
        output_file = Path(self.output_path.get().strip())
        try:
            delay = float(self.delay_var.get().strip())
        except ValueError:
            messagebox.showerror(APP_TITLE, "间隔秒数必须是数字。")
            return

        if not keywords_file.exists():
            messagebox.showerror(APP_TITLE, f"未找到关键词文件：\n{keywords_file}")
            return

        self.tree.delete(*self.tree.get_children())
        self.stop_flag.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress_var.set(0)
        self.status_var.set("正在启动...")

        self.worker = threading.Thread(
            target=self._run_task,
            args=(keywords_file, output_file, delay, self.headless_var.get(), self.save_html_var.get()),
            daemon=True,
        )
        self.worker.start()

    def stop_task(self) -> None:
        self.stop_flag.set()
        self.status_var.set("将在当前关键词完成后停止...")

    def _run_task(self, keywords_file: Path, output_file: Path, delay: float, headless: bool, save_html: bool) -> None:
        try:
            keywords = read_keywords(keywords_file)
            if not keywords:
                self.msg_queue.put(("error", "TXT 文件中没有读到有效关键词。"))
                return

            output_file.parent.mkdir(parents=True, exist_ok=True)
            extractor = DomainExtractor(logger=self.logger, headless=headless, delay=delay, save_html=save_html)
            extractor.start()

            try:
                rows: List[SearchResult] = []
                total = len(keywords)
                for idx, keyword in enumerate(keywords, start=1):
                    if self.stop_flag.is_set():
                        self.logger.write("用户请求停止，当前关键词完成后结束。")
                        break
                    result = extractor.search_keyword(keyword)
                    rows.append(result)
                    self.msg_queue.put(("row", result))
                    pct = idx / total * 100
                    self.msg_queue.put(("progress", (pct, f"已处理 {idx}/{total}：{keyword}")))
                write_csv(output_file, rows)
                self.msg_queue.put(("done", f"处理完成。CSV 已保存到：\n{output_file}"))
            finally:
                extractor.close()
        except Exception as exc:
            self.msg_queue.put(("error", f"未处理异常：\n{exc}"))

    def _process_queue(self) -> None:
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self._append_log(str(payload))
                elif kind == "row":
                    self._add_row(payload)
                elif kind == "progress":
                    pct, text = payload
                    self.progress_var.set(pct)
                    self.status_var.set(text)
                elif kind == "done":
                    self._finish(True, str(payload))
                elif kind == "error":
                    self._finish(False, str(payload))
        except queue.Empty:
            pass
        self.root.after(100, self._process_queue)

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _add_row(self, result: SearchResult) -> None:
        vals = [result.keyword] + result.domains[:10]
        vals += [""] * (11 - len(vals))
        self.tree.insert("", "end", values=vals)
        if result.note:
            self._append_log(f"[{result.keyword}] {result.status}：{result.note}")
        else:
            self._append_log(f"[{result.keyword}] {result.status}: {', '.join(result.domains[:10])}")

    def _finish(self, ok: bool, message: str) -> None:
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.progress_var.set(100 if ok else self.progress_var.get())
        self.status_var.set("已完成" if ok else "出错")
        if ok:
            messagebox.showinfo(APP_TITLE, message)
        else:
            messagebox.showerror(APP_TITLE, message)


def read_text_best_effort(path: Path) -> str:
    raw = path.read_bytes()
    encodings = ["utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16", "utf-16le", "utf-16be"]
    for enc in encodings:
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="ignore")


def normalize_keyword(text: str) -> str:
    cleaned = text.replace("﻿", "").replace("​", "").replace("‌", "").replace("‍", "")
    cleaned = cleaned.replace(" ", " ").replace("　", " ").replace("	", " ")
    cleaned = re.sub(r"\s+", " ", cleaned or "").strip()
    return cleaned


def read_keywords(path: Path) -> List[str]:
    content = read_text_best_effort(path)
    keywords = []
    seen = set()
    for line in content.splitlines():
        kw = normalize_keyword(line)
        if not kw:
            continue
        if kw in seen:
            continue
        seen.add(kw)
        keywords.append(kw)
    return keywords


def write_csv(path: Path, rows: Sequence[SearchResult]) -> None:
    headers = ["关键词", "状态", "备注"] + [f"第{i}个域名" for i in range(1, 11)]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in rows:
            values = [row.keyword, row.status, row.note] + row.domains[:10]
            values += [""] * (len(headers) - len(values))
            writer.writerow(values)


def merge_unique_strings(existing: Sequence[str], new_items: Sequence[str]) -> List[str]:
    out = []
    seen = set()
    for item in list(existing) + list(new_items):
        key = (item or "").strip()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(key)
    return out


def extract_host(url: str) -> str:
    try:
        host = urlsplit(url).hostname or ""
    except Exception:
        return ""
    host = host.strip().lower().rstrip(".")
    return host


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def safe_int(value: object, default: int = 0) -> int:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def dedupe_strings(items: Iterable[str]) -> List[str]:
    seen = set()
    out = []
    for item in items:
        key = item.strip()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(key)
    return out


def main() -> None:
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
