@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0run_gui.ps1"
