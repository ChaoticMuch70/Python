import csv
import os
import queue
import random
import re
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote, urljoin, urlsplit

import requests
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

APP_TITLE = "Baidu Mobile Top10 Domains"
DEFAULT_OUTPUT = "baidu_mobile_top10_domains.csv"
DEFAULT_LOG = "baidu_mobile_top10_domains.log"
DEFAULT_KEYWORDS = "keywords.txt"
MAX_RESULTS = 10

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
)

EXCLUDED_HOST_KEYWORDS = {
    "m.baidu.com",
    "www.baidu.com",
    "baijiahao.baidu.com",
    "mbd.baidu.com",
    "wk.baidu.com",
    "tieba.baidu.com",
    "zhidao.baidu.com",
    "image.baidu.com",
    "wenku.baidu.com",
    "map.baidu.com",
    "v.baidu.com",
    "video.baidu.com",
    "news.baidu.com",
    "passport.baidu.com",
    "voice.baidu.com",
    "smartapp.baidu.com",
    "uf9kyh.smartapps.cn",
}

RESULT_SELECTORS = [
    "div.result h3 a[href]",
    "div[class*='result'] h3 a[href]",
    "div[class*='c-result'] h3 a[href]",
    "div[data-log] h3 a[href]",
    "article h3 a[href]",
    "h3 a[href]",
    "a[data-module][href]",
]


def get_app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = get_app_dir()
LOG_PATH = APP_DIR / DEFAULT_LOG
DEBUG_DIR = APP_DIR / "debug_html"


class Logger:
    def __init__(self, callback=None):
        self.callback = callback

    def write(self, message: str) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {message}"
        try:
            with LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        if self.callback:
            self.callback(line)


@dataclass
class SearchResult:
    keyword: str
    domains: List[str]
    status: str
    note: str = ""


class DomainExtractor:
    def __init__(self, logger: Logger, headless: bool = True, delay: float = 1.5, save_html: bool = False):
        self.logger = logger
        self.headless = headless
        self.delay = max(0.0, delay)
        self.save_html = save_html
        self.driver: Optional[webdriver.Chrome] = None
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "zh-CN,zh;q=0.9",
        })

    def start(self) -> None:
        options = Options()
        mobile_emulation = {
            "deviceMetrics": {"width": 412, "height": 915, "pixelRatio": 2.625},
            "userAgent": USER_AGENT,
        }
        options.add_experimental_option("mobileEmulation", mobile_emulation)
        options.add_argument("--lang=zh-CN")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=430,960")
        if self.headless:
            options.add_argument("--headless=new")
        self.driver = webdriver.Chrome(service=Service(), options=options)
        self.driver.set_page_load_timeout(45)
        self.logger.write("Chrome driver started.")

    def close(self) -> None:
        try:
            if self.driver:
                self.driver.quit()
        except Exception:
            pass
        self.driver = None

    def search_keyword(self, keyword: str) -> SearchResult:
        assert self.driver is not None, "Driver not started"
        query = keyword.strip()
        if not query:
            return SearchResult(keyword=query, domains=[], status="skip", note="Empty keyword")

        url = f"https://m.baidu.com/s?word={quote(query)}"
        self.logger.write(f"Searching keyword: {query}")

        try:
            self.driver.get(url)
            self._wait_for_page_ready()
            time.sleep(self.delay + random.uniform(0.4, 1.2))
        except TimeoutException:
            self.logger.write(f"Page load timeout: {query}")
        except WebDriverException as exc:
            return SearchResult(keyword=query, domains=[], status="error", note=f"Browser error: {exc}")

        self._try_expand_results()
        html = self.driver.page_source
        current_url = self.driver.current_url
        page_title = self.driver.title or ""

        if self.save_html:
            self._save_debug_html(query, html)

        if self._looks_like_blocked(html, current_url, page_title):
            self._save_debug_html(query, html)
            return SearchResult(keyword=query, domains=[], status="blocked", note="Baidu may have shown verification or blocked the request")

        anchors = self._collect_candidate_anchors()
        if not anchors:
            anchors = self._extract_candidate_anchors_from_html(html, current_url)

        domains = self._resolve_domains(anchors)
        if not domains:
            self._save_debug_html(query, html)
            return SearchResult(keyword=query, domains=[], status="empty", note="No result domains extracted")

        if len(domains) < MAX_RESULTS:
            note = f"Only extracted {len(domains)} domains"
            status = "partial"
        else:
            note = ""
            status = "ok"
        return SearchResult(keyword=query, domains=domains[:MAX_RESULTS], status=status, note=note)

    def _wait_for_page_ready(self) -> None:
        assert self.driver is not None
        wait = WebDriverWait(self.driver, 20)
        try:
            wait.until(lambda d: d.execute_script("return document.readyState") == "complete")
        except TimeoutException:
            pass
        selectors = [
            "h3 a[href]",
            "div.result",
            "div[class*='result']",
            "div[data-log]",
            "body",
        ]
        for selector in selectors:
            try:
                wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                return
            except TimeoutException:
                continue

    def _try_expand_results(self) -> None:
        assert self.driver is not None
        candidates = [
            "查看更多",
            "展开更多",
            "显示更多",
            "下一页",
            "加载更多",
        ]
        try:
            buttons = self.driver.find_elements(By.XPATH, "//a|//button|//div")
        except Exception:
            return
        for btn in buttons[:200]:
            try:
                text = (btn.text or "").strip()
                if text in candidates:
                    self.driver.execute_script("arguments[0].click();", btn)
                    time.sleep(1.0)
                    break
            except Exception:
                continue

    def _looks_like_blocked(self, html: str, current_url: str, page_title: str) -> bool:
        signals = [
            current_url,
            page_title,
            html[:5000],
        ]
        joined = "\n".join(s for s in signals if s).lower()
        patterns = [
            "验证码",
            "安全验证",
            "请完成以下验证",
            "请输入验证码",
            "访问受限",
            "network anomaly",
            "verify",
            "captcha",
            "antirobot",
        ]
        return any(p.lower() in joined for p in patterns)

    def _collect_candidate_anchors(self) -> List[Tuple[str, str]]:
        assert self.driver is not None
        js = r'''
        const selectors = arguments[0];
        const seen = new Set();
        const items = [];
        for (const selector of selectors) {
          document.querySelectorAll(selector).forEach(a => {
            if (!a || !a.href) return;
            if (seen.has(a)) return;
            seen.add(a);
            const text = (a.innerText || a.textContent || '').trim();
            items.push({href: a.href, text});
          });
        }
        return items;
        '''
        items = []
        try:
            raw = self.driver.execute_script(js, RESULT_SELECTORS) or []
        except Exception:
            raw = []

        for item in raw:
            href = (item.get("href") or "").strip()
            text = (item.get("text") or "").strip()
            if self._is_candidate_anchor(href, text):
                items.append((href, text))
        return self._dedupe_preserve_order(items)

    def _extract_candidate_anchors_from_html(self, html: str, current_url: str) -> List[Tuple[str, str]]:
        soup = BeautifulSoup(html, "html.parser")
        items: List[Tuple[str, str]] = []
        selectors = [
            "div.result h3 a[href]",
            "div[class*='result'] h3 a[href]",
            "div[data-log] h3 a[href]",
            "h3 a[href]",
        ]
        for selector in selectors:
            for a in soup.select(selector):
                href = urljoin(current_url, (a.get("href") or "").strip())
                text = a.get_text(" ", strip=True)
                if self._is_candidate_anchor(href, text):
                    items.append((href, text))
        return self._dedupe_preserve_order(items)

    def _is_candidate_anchor(self, href: str, text: str) -> bool:
        if not href:
            return False
        href_l = href.lower()
        if href_l.startswith(("javascript:", "mailto:", "tel:")):
            return False
        if href_l.startswith("#"):
            return False
        bad_parts = [
            "passport.baidu.com",
            "/from=844b/",
            "voice.baidu.com",
            "image.baidu.com",
            "map.baidu.com",
            "mbd.baidu.com/ma/s/",
            "www.baidu.com/from=",
        ]
        if any(p in href_l for p in bad_parts):
            return False
        bad_text = ["百度一下", "相关搜索", "下一页", "上一页", "更多结果", "使用百度前必读"]
        if text and any(t in text for t in bad_text):
            return False
        return href_l.startswith("http")

    def _resolve_domains(self, anchors: Sequence[Tuple[str, str]]) -> List[str]:
        domains: List[str] = []
        for href, text in anchors:
            if len(domains) >= MAX_RESULTS:
                break
            final_url = self._resolve_url(href)
            host = extract_host(final_url)
            if not host:
                continue
            if self._should_skip_host(host, text):
                continue
            domains.append(host)
        return domains

    def _resolve_url(self, href: str) -> str:
        host = extract_host(href)
        if host and not host.endswith("baidu.com") and not host.endswith("baidu.cn"):
            return href

        try:
            response = self.session.get(href, timeout=15, allow_redirects=True)
            return response.url or href
        except Exception:
            return href

    def _should_skip_host(self, host: str, text: str) -> bool:
        host = host.lower()
        if host in EXCLUDED_HOST_KEYWORDS:
            return True
        if host.endswith("baidu.com") or host.endswith("baidu.cn"):
            # Keep only if query explicitly wants Baidu properties.
            title = (text or "").lower()
            if "百度" not in title:
                return True
        return False

    def _save_debug_html(self, keyword: str, html: str) -> None:
        DEBUG_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff._-]+", "_", keyword).strip("._") or "keyword"
        path = DEBUG_DIR / f"{safe_name}.html"
        try:
            path.write_text(html, encoding="utf-8")
            self.logger.write(f"Debug HTML saved: {path}")
        except Exception as exc:
            self.logger.write(f"Failed to save debug HTML: {exc}")

    @staticmethod
    def _dedupe_preserve_order(items: Iterable[Tuple[str, str]]) -> List[Tuple[str, str]]:
        seen = set()
        out = []
        for href, text in items:
            key = (href.strip(), text.strip())
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("960x680")
        self.root.minsize(860, 620)

        self.msg_queue: queue.Queue[Tuple[str, object]] = queue.Queue()
        self.worker: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()

        self.keywords_path = tk.StringVar(value=str(APP_DIR / DEFAULT_KEYWORDS))
        self.output_path = tk.StringVar(value=str(APP_DIR / DEFAULT_OUTPUT))
        self.headless_var = tk.BooleanVar(value=True)
        self.save_html_var = tk.BooleanVar(value=False)
        self.delay_var = tk.StringVar(value="1.5")
        self.status_var = tk.StringVar(value="Ready")
        self.progress_var = tk.DoubleVar(value=0.0)

        self._build_ui()
        self.logger = Logger(self._enqueue_log)
        self.root.after(100, self._process_queue)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        form = ttk.LabelFrame(outer, text="Task Settings", padding=12)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Keywords TXT").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.keywords_path).grid(row=0, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="Browse", command=self._browse_keywords).grid(row=0, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="Output CSV").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.output_path).grid(row=1, column=1, sticky="ew", pady=6)
        ttk.Button(form, text="Browse", command=self._browse_output).grid(row=1, column=2, padx=(8, 0), pady=6)

        ttk.Label(form, text="Delay (sec)").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(form, textvariable=self.delay_var, width=12).grid(row=2, column=1, sticky="w", pady=6)

        opts = ttk.Frame(form)
        opts.grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Checkbutton(opts, text="Headless Chrome", variable=self.headless_var).pack(side="left", padx=(0, 18))
        ttk.Checkbutton(opts, text="Save HTML for every keyword", variable=self.save_html_var).pack(side="left")

        tip = ttk.Label(
            outer,
            text=(
                "Input TXT format: one keyword per line. The program searches each line on m.baidu.com, "
                "then exports the first 10 result domains."
            ),
            wraplength=900,
            justify="left",
        )
        tip.pack(fill="x", pady=(10, 8))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 8))
        self.start_btn = ttk.Button(btns, text="Start", command=self.start_task)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="Stop After Current Keyword", command=self.stop_task, state="disabled")
        self.stop_btn.pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="Open App Folder", command=self._open_app_folder).pack(side="right")

        progress_frame = ttk.Frame(outer)
        progress_frame.pack(fill="x", pady=(0, 8))
        self.progress = ttk.Progressbar(progress_frame, maximum=100, variable=self.progress_var)
        self.progress.pack(fill="x")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w", pady=(4, 0))

        table_box = ttk.LabelFrame(outer, text="Results Preview", padding=8)
        table_box.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table_box, columns=["keyword"] + [f"d{i}" for i in range(1, 11)], show="headings", height=10)
        self.tree.heading("keyword", text="Keyword")
        self.tree.column("keyword", width=220, anchor="w")
        for i in range(1, 11):
            col = f"d{i}"
            self.tree.heading(col, text=f"Top {i}")
            self.tree.column(col, width=150, anchor="w")
        yscroll = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_box.columnconfigure(0, weight=1)
        table_box.rowconfigure(0, weight=1)

        log_box = ttk.LabelFrame(outer, text="Log", padding=8)
        log_box.pack(fill="both", expand=True, pady=(8, 0))
        self.log_text = tk.Text(log_box, height=12, wrap="word")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

    def _browse_keywords(self) -> None:
        path = filedialog.askopenfilename(
            title="Select keywords TXT",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
        )
        if path:
            self.keywords_path.set(path)

    def _browse_output(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Save CSV As",
            defaultextension=".csv",
            initialfile=DEFAULT_OUTPUT,
            filetypes=[("CSV Files", "*.csv")],
        )
        if path:
            self.output_path.set(path)

    def _open_app_folder(self) -> None:
        path = str(APP_DIR)
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo(APP_TITLE, path)

    def _enqueue_log(self, line: str) -> None:
        self.msg_queue.put(("log", line))

    def start_task(self) -> None:
        if self.worker and self.worker.is_alive():
            return

        keywords_file = Path(self.keywords_path.get().strip())
        output_file = Path(self.output_path.get().strip())
        try:
            delay = float(self.delay_var.get().strip())
        except ValueError:
            messagebox.showerror(APP_TITLE, "Delay must be a number.")
            return

        if not keywords_file.exists():
            messagebox.showerror(APP_TITLE, f"Keywords file not found:\n{keywords_file}")
            return

        self.tree.delete(*self.tree.get_children())
        self.stop_flag.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress_var.set(0)
        self.status_var.set("Starting...")

        self.worker = threading.Thread(
            target=self._run_task,
            args=(keywords_file, output_file, delay, self.headless_var.get(), self.save_html_var.get()),
            daemon=True,
        )
        self.worker.start()

    def stop_task(self) -> None:
        self.stop_flag.set()
        self.status_var.set("Stopping after current keyword...")

    def _run_task(self, keywords_file: Path, output_file: Path, delay: float, headless: bool, save_html: bool) -> None:
        try:
            keywords = read_keywords(keywords_file)
            if not keywords:
                self.msg_queue.put(("error", "No valid keywords found in the TXT file."))
                return

            output_file.parent.mkdir(parents=True, exist_ok=True)
            extractor = DomainExtractor(logger=self.logger, headless=headless, delay=delay, save_html=save_html)
            extractor.start()

            try:
                rows: List[SearchResult] = []
                total = len(keywords)
                for idx, keyword in enumerate(keywords, start=1):
                    if self.stop_flag.is_set():
                        self.logger.write("Stop requested by user.")
                        break
                    result = extractor.search_keyword(keyword)
                    rows.append(result)
                    self.msg_queue.put(("row", result))
                    pct = idx / total * 100
                    self.msg_queue.put(("progress", (pct, f"Processed {idx}/{total}: {keyword}")))
                write_csv(output_file, rows)
                self.msg_queue.put(("done", f"Completed. CSV saved to:\n{output_file}"))
            finally:
                extractor.close()
        except Exception as exc:
            self.msg_queue.put(("error", f"Unhandled error:\n{exc}"))

    def _process_queue(self) -> None:
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self._append_log(str(payload))
                elif kind == "row":
                    self._add_row(payload)
                elif kind == "progress":
                    pct, text = payload
                    self.progress_var.set(pct)
                    self.status_var.set(text)
                elif kind == "done":
                    self._finish(True, str(payload))
                elif kind == "error":
                    self._finish(False, str(payload))
        except queue.Empty:
            pass
        self.root.after(100, self._process_queue)

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _add_row(self, result: SearchResult) -> None:
        vals = [result.keyword] + result.domains[:10]
        vals += [""] * (11 - len(vals))
        self.tree.insert("", "end", values=vals)
        if result.note:
            self._append_log(f"[{result.keyword}] {result.status}: {result.note}")
        else:
            self._append_log(f"[{result.keyword}] {result.status}: {', '.join(result.domains[:10])}")

    def _finish(self, ok: bool, message: str) -> None:
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.progress_var.set(100 if ok else self.progress_var.get())
        self.status_var.set("Finished" if ok else "Error")
        if ok:
            messagebox.showinfo(APP_TITLE, message)
        else:
            messagebox.showerror(APP_TITLE, message)


def read_keywords(path: Path) -> List[str]:
    content = path.read_text(encoding="utf-8-sig", errors="ignore")
    keywords = []
    seen = set()
    for line in content.splitlines():
        kw = line.strip()
        if not kw:
            continue
        if kw in seen:
            continue
        seen.add(kw)
        keywords.append(kw)
    return keywords


def write_csv(path: Path, rows: Sequence[SearchResult]) -> None:
    headers = ["keyword", "status", "note"] + [f"top_{i}_domain" for i in range(1, 11)]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in rows:
            values = [row.keyword, row.status, row.note] + row.domains[:10]
            values += [""] * (len(headers) - len(values))
            writer.writerow(values)


def extract_host(url: str) -> str:
    try:
        host = urlsplit(url).hostname or ""
    except Exception:
        return ""
    host = host.strip().lower().rstrip(".")
    return host


def main() -> None:
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
