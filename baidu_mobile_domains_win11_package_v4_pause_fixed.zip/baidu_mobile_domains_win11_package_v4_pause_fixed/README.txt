﻿Baidu Mobile Top10 Domains - Windows 11 package

What this tool does:
1. Read a TXT file with one keyword per line.
2. Search each keyword on https://m.baidu.com
3. Extract the first 10 result domains.
4. Save results to a CSV file.

Important notes:
- Install Google Chrome before running.
- First launch may need internet so Selenium Manager can prepare the matching Chrome driver.
- Baidu may occasionally show verification / captcha / anti-bot pages. When that happens, the tool will mark the row as blocked or empty.
- If you enable "Save HTML for every keyword", debug HTML files are saved under the folder: debug_html

How to run the GUI:
1. Make sure Python 3.11+ works in PowerShell.
2. Double-click run_gui.bat, or run .\run_gui.ps1 in PowerShell.
3. Choose the keywords TXT and output CSV.
4. Click Start.

How to build the EXE:
1. Double-click build_gui_exe.bat, or run .\build_gui_exe.ps1 in PowerShell.
2. After build, the EXE will be in: dist\baidu_mobile_top10_domains.exe

Files generated during runtime:
- baidu_mobile_top10_domains.csv
- baidu_mobile_top10_domains.log
- debug_html\*.html (when enabled or when extraction fails)


更新说明（本版）
1. 当某个关键词没有搜索结果时，程序会更快判定为“无结果”并跳过，减少卡住等待。
2. 界面新增“导出当前结果”按钮，运行中也可手动导出。
3. 每处理完一个关键词，程序都会自动覆盖保存一次当前 CSV，减少中途停止或异常导致的数据丢失。
